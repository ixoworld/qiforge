import {
  operationJsonSchema,
  operationKinds,
  validateOperationSchema,
} from "./operation-schema.js";
export { operationJsonSchema, operationKinds };
const ID = /^[A-Za-z0-9_-]{32}$/;
const HEX = /^[a-f0-9]{64}$/;
const ADDRESS = /^ixo1[023456789acdefghjklmnpqrstuvwxyz]{38,59}$/;
const INT = /^(0|[1-9][0-9]*)$/;
const FIELD = /^[a-z][a-z0-9_]{0,39}$/;
/** Envelope tags. v1 carries only the 0.1 status/receipt set; v2 adds terminal non-execution outcomes. */
export const OUTCOME_VERSION_V1 = "ixo.auth-outcome/1";
export const OUTCOME_VERSION_V2 = "ixo.auth-outcome/2";
export const CAPABILITIES_VERSION_V1 = "ixo.auth-capabilities/1";
export const CAPABILITIES_VERSION_V2 = "ixo.auth-capabilities/2";
const MEMO_BYTES = 256;
/** 0.2.1: mainnet is a valid network value; enablement is a Hub deployment decision. */
export const NETWORKS = ["ixo mainnet", "ixo testnet", "ixo devnet"];
/**
 * 0.4.1: authorization / statement-proof `network` (bare names). Every ixo
 * network is valid; the receiver must require its own deployment's network.
 */
export const SERVICE_NETWORKS = ["mainnet", "testnet", "devnet"];
const V1_OUTCOME_STATUSES = [
  "authorized",
  "declined",
  "submitted",
  "succeeded",
  "failed",
  "unknown",
];
/** The 0.1.0 receipt and operation sets: the only ones a v1 envelope may carry. */
const V1_RECEIPT_KINDS = ["form.submission.v1", "ixo.bank.send.v1"];
export const V1_OPERATION_KINDS = [
  "form.submit.v1",
  "ixo.bank.send.v1",
  "resource.read.v1",
];
/** Terminal outcomes for an action that never executed (v2 only, receipt always null). */
const V2_ONLY_OUTCOME_STATUSES = ["expired", "cancelled"];
export const OUTCOME_SEQUENCE = {
  authorized: 1,
  declined: 1,
  submitted: 2,
  unknown: 3,
  succeeded: 4,
  failed: 4,
  expired: 5,
  cancelled: 5,
};
/** A transfer that was signed but never included in a block (`height` is null). */
export const BANK_NOT_INCLUDED_REASONS = [
  "check_tx_rejected",
  "expired_not_included",
];
const fail = (field) => {
  throw new TypeError(`Invalid ${field}`);
};
const object = (value, field) =>
  value && typeof value === "object" && !Array.isArray(value)
    ? value
    : fail(field);
const exact = (value, keys, field) => {
  for (const key of Object.keys(value)) if (!keys.includes(key)) fail(field);
};
const str = (value, field, min = 1, max = 200) =>
  typeof value === "string" && value.length >= min && value.length <= max
    ? value
    : fail(field);
const num = (value, field) =>
  Number.isSafeInteger(value) && value > 0 ? value : fail(field);
const pattern = (value, regex, field) =>
  regex.test(str(value, field)) ? value : fail(field);

export function canonicalJson(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value))
    return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (
    value &&
    typeof value === "object" &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    const keys = Object.keys(value).sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return fail("canonical JSON");
}

export async function digestOf(value) {
  const bytes = new TextEncoder().encode(canonicalJson(value));
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}

export function parseOperation(input) {
  const op = object(input, "operation");
  validateOperationSchema(op);
  if (op.kind === "statement.sign.v1") {
    utf8(op.statement, "statement");
    return op;
  }
  if (op.kind === "vfs.text.save.v1") {
    utf8(op.text, "text");
    privateTextPath("A".repeat(32), op.filename);
    return op;
  }
  if (op.kind.startsWith("gmail.")) {
    for (const field of [
      "accountLabel",
      ...(op.kind === "gmail.message.send.v1" ? ["to"] : []),
    ]) {
      if (op[field] !== null && op[field].split("@")[0].length > 64)
        fail(field);
    }
    if (op.kind === "gmail.message.send.v1") {
      utf8(op.subject, "subject");
      utf8(op.body, "body");
    }
    return op;
  }
  if (op.kind === "calendar.event.create.v1") {
    if (!validCalendarInstant(op.startsAt) || !validCalendarInstant(op.endsAt))
      fail("calendar instant");
    const start = Date.parse(op.startsAt),
      end = Date.parse(op.endsAt);
    if (
      !Number.isFinite(start) ||
      !Number.isFinite(end) ||
      end <= start ||
      end - start > 86400000
    )
      fail("event duration");
    try {
      new Intl.DateTimeFormat("en", { timeZone: op.timeZone });
    } catch {
      fail("timeZone");
    }
    return op;
  }
  if (
    [
      "calendar.connect.v1",
      "calendar.disconnect.v1",
      "vfs.access.request.v1",
    ].includes(op.kind)
  )
    return op;
  if (op.kind === "form.submit.v1") {
    exact(
      op,
      ["kind", "formId", "destination", "fields", "declaration"],
      "operation",
    );
    str(op.formId, "formId", 1, 120);
    str(op.destination, "destination", 1, 200);
    if (
      !Array.isArray(op.fields) ||
      op.fields.length < 1 ||
      op.fields.length > 20
    )
      fail("fields");
    const ids = new Set();
    for (const field of op.fields) {
      object(field, "field");
      exact(
        field,
        ["id", "label", "type", "required", "value", "source"],
        "field",
      );
      pattern(field.id, FIELD, "field.id");
      if (ids.has(field.id)) fail("duplicate field");
      ids.add(field.id);
      str(field.label, "field.label", 1, 120);
      if (!["text", "email", "tel", "textarea"].includes(field.type))
        fail("field.type");
      if (typeof field.required !== "boolean") fail("field.required");
      str(field.value, "field.value", 0, 1000);
      if (!["user", "record", "suggestion"].includes(field.source))
        fail("field.source");
    }
    if (op.declaration !== null) str(op.declaration, "declaration", 1, 120);
    return op;
  }
  if (op.kind === "ixo.bank.send.v1") {
    exact(
      op,
      [
        "kind",
        "chainId",
        "network",
        "fromAddress",
        "toAddress",
        "amountBaseUnits",
        "denom",
        "feeBaseUnits",
        "memo",
      ],
      "operation",
    );
    str(op.chainId, "chainId", 1, 100);
    // Every ixo network is expressible; a Hub executes only its own chain.
    if (!NETWORKS.includes(op.network)) fail("network");
    pattern(op.fromAddress, ADDRESS, "fromAddress");
    pattern(op.toAddress, ADDRESS, "toAddress");
    if (op.fromAddress === op.toAddress) fail("self transfer");
    pattern(op.amountBaseUnits, INT, "amountBaseUnits");
    if (op.amountBaseUnits === "0") fail("amountBaseUnits");
    if (op.denom !== "uixo") fail("denom");
    pattern(op.feeBaseUnits, INT, "feeBaseUnits");
    str(op.memo, "memo", 0, 256);
    // Cosmos SDK x/auth max_memo_characters counts UTF-8 bytes, not UTF-16 units.
    if (new TextEncoder().encode(op.memo).length > MEMO_BYTES) fail("memo");
    return op;
  }
  if (op.kind === "resource.read.v1") {
    exact(
      op,
      ["kind", "resourceId", "ownerDid", "url", "version", "contentDigest"],
      "operation",
    );
    str(op.resourceId, "resourceId", 1, 200);
    str(op.ownerDid, "ownerDid", 1, 200);
    const url = new URL(str(op.url, "resource.url", 1, 2000));
    if (url.protocol !== "https:" || url.username || url.password || url.hash)
      fail("resource.url");
    str(op.version, "resource.version", 1, 200);
    pattern(op.contentDigest, HEX, "resource.contentDigest");
    return op;
  }
  return fail("operation.kind");
}

export function parseReference(input) {
  const ref = object(input, "reference");
  exact(
    ref,
    [
      "version",
      "id",
      "accountId",
      "bindingId",
      "bindingRevision",
      "revision",
      "digest",
      "url",
      "expiresAt",
      "title",
    ],
    "reference",
  );
  if (ref.version !== "ixo.auth-action/1") fail("reference.version");
  pattern(ref.id, ID, "reference.id");
  str(ref.accountId, "reference.accountId", 1, 100);
  str(ref.bindingId, "reference.bindingId", 1, 100);
  num(ref.bindingRevision, "reference.bindingRevision");
  num(ref.revision, "reference.revision");
  pattern(ref.digest, HEX, "reference.digest");
  const url = new URL(str(ref.url, "reference.url", 1, 2000));
  if (
    !(
      url.protocol === "https:" ||
      (url.protocol === "http:" && url.hostname === "localhost")
    ) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    url.pathname !== `/a/${ref.id}`
  )
    fail("reference.url");
  num(ref.expiresAt, "reference.expiresAt");
  str(ref.title, "reference.title", 1, 80);
  return ref;
}

export function assertHubReferenceUrl(input, configuredOrigin) {
  const ref = parseReference(input);
  const configured = new URL(configuredOrigin);
  if (
    !(
      configured.protocol === "https:" ||
      (configured.protocol === "http:" && configured.hostname === "localhost")
    ) ||
    configured.pathname !== "/" ||
    configured.search ||
    configured.hash ||
    new URL(ref.url).origin !== configured.origin
  )
    fail("reference.url.origin");
  return ref;
}

export function parseReceipt(input) {
  const receipt = object(input, "receipt");
  if (p2ReceiptFields[receipt.kind]) return parseP2Receipt(receipt);
  if (receipt.kind === "form.submission.v1") {
    exact(
      receipt,
      [
        "kind",
        "actionId",
        "revision",
        "digest",
        "valuesDigest",
        "submittedAt",
        "submissionId",
      ],
      "receipt",
    );
    pattern(receipt.actionId, ID, "receipt.actionId");
    num(receipt.revision, "receipt.revision");
    pattern(receipt.digest, HEX, "receipt.digest");
    pattern(receipt.valuesDigest, HEX, "receipt.valuesDigest");
    num(receipt.submittedAt, "receipt.submittedAt");
    str(receipt.submissionId, "receipt.submissionId", 1, 100);
    return receipt;
  }
  if (receipt.kind === "ixo.bank.send.v1") {
    exact(
      receipt,
      [
        "kind",
        "actionId",
        "revision",
        "digest",
        "chainId",
        "txHash",
        "height",
        "code",
        "reason",
      ],
      "receipt",
    );
    pattern(receipt.actionId, ID, "receipt.actionId");
    num(receipt.revision, "receipt.revision");
    pattern(receipt.digest, HEX, "receipt.digest");
    str(receipt.chainId, "receipt.chainId", 1, 100);
    pattern(receipt.txHash, HEX, "receipt.txHash");
    if (receipt.height !== null) num(receipt.height, "receipt.height");
    if (
      receipt.code !== null &&
      (!Number.isSafeInteger(receipt.code) || receipt.code < 0)
    )
      fail("receipt.code");
    if ("reason" in receipt) {
      if (
        !BANK_NOT_INCLUDED_REASONS.includes(receipt.reason) ||
        receipt.height !== null ||
        (receipt.reason === "check_tx_rejected" &&
          (receipt.code === null || receipt.code === 0)) ||
        (receipt.reason === "expired_not_included" && receipt.code !== null)
      )
        fail("receipt.reason");
    }
    return receipt;
  }
  return fail("receipt.kind");
}

export function parseReviewView(input) {
  const view = object(input, "view");
  exact(
    view,
    [
      "reference",
      "requester",
      "operation",
      "reviewStatus",
      "operationStatus",
      "revision",
      "digest",
      "canEdit",
      "canApprove",
      "canSign",
      "receipt",
      "signedTxHash",
      "resourceUrl",
      "chatUrl",
      "service",
    ],
    "view",
  );
  parseReference(view.reference);
  if (view.service !== undefined && view.service !== null) {
    object(view.service, "view.service");
    exact(
      view.service,
      ["continuationUrl", "accountLabel", "resource"],
      "view.service",
    );
    nullableUrl(view.service.continuationUrl);
    nullableString(view.service.accountLabel, "accountLabel", 200);
    if (view.service.resource !== null)
      parseResourceDescriptor(view.service.resource);
  }
  str(view.requester, "view.requester", 1, 120);
  parseOperation(view.operation);
  if (
    ![
      "prepared",
      "superseded",
      "declined",
      "expired",
      "revoked",
      "signing",
      "authorized",
    ].includes(view.reviewStatus)
  )
    fail("view.reviewStatus");
  if (
    ![
      "awaiting_authorization",
      "admitted",
      "submitted",
      "succeeded",
      "failed",
      "requires_review",
      "unknown",
      "not_started",
    ].includes(view.operationStatus)
  )
    fail("view.operationStatus");
  num(view.revision, "view.revision");
  pattern(view.digest, HEX, "view.digest");
  for (const key of ["canEdit", "canApprove", "canSign"])
    if (typeof view[key] !== "boolean") fail(`view.${key}`);
  if (view.receipt !== null) {
    const receipt = parseReceipt(view.receipt);
    if (
      receipt.actionId !== view.reference.id ||
      receipt.revision !== view.revision ||
      receipt.digest !== view.digest
    )
      fail("view.receipt");
    assertReceiptForOperation(view.operation, receipt, view.operationStatus);
    if (
      view.operation.kind === "form.submit.v1" &&
      receipt.kind !== "form.submission.v1"
    )
      fail("view.receipt");
    if (
      view.operation.kind === "ixo.bank.send.v1" &&
      receipt.kind !== "ixo.bank.send.v1"
    )
      fail("view.receipt");
    if (!receiptFitsStatus(receipt, view.operationStatus)) fail("view.receipt");
  }
  if (
    ["succeeded", "failed"].includes(view.operationStatus) &&
    view.receipt === null
  )
    fail("view.receipt");
  // `not_started`: terminal, nothing was executed (for example a decline).
  if (view.operationStatus === "not_started" && view.receipt !== null)
    fail("view.receipt");
  if (view.signedTxHash !== null)
    pattern(view.signedTxHash, HEX, "view.signedTxHash");
  if (view.resourceUrl !== null) {
    const url = new URL(str(view.resourceUrl, "view.resourceUrl", 1, 2000));
    if (
      !(
        url.protocol === "https:" ||
        (url.protocol === "http:" && url.hostname === "localhost")
      ) ||
      url.username ||
      url.password ||
      url.hash
    )
      fail("view.resourceUrl");
  }
  const chat = new URL(str(view.chatUrl, "view.chatUrl", 1, 2000));
  if (chat.protocol !== "https:" || chat.username || chat.password)
    fail("view.chatUrl");
  return view;
}

export function parseOutcome(input) {
  const outcome = object(input, "outcome");
  exact(
    outcome,
    [
      "version",
      "eventId",
      "reference",
      "ownerDid",
      "authorizedRevision",
      "authorizedDigest",
      "sequence",
      "status",
      "receipt",
      "occurredAt",
    ],
    "outcome",
  );
  if (![OUTCOME_VERSION_V1, OUTCOME_VERSION_V2].includes(outcome.version))
    fail("outcome.version");
  const v2 = outcome.version === OUTCOME_VERSION_V2;
  str(outcome.eventId, "outcome.eventId", 1, 100);
  const ref = parseReference(outcome.reference);
  str(outcome.ownerDid, "outcome.ownerDid", 1, 200);
  num(outcome.authorizedRevision, "outcome.authorizedRevision");
  pattern(outcome.authorizedDigest, HEX, "outcome.authorizedDigest");
  num(outcome.sequence, "outcome.sequence");
  if (
    !V1_OUTCOME_STATUSES.includes(outcome.status) &&
    !(v2 && V2_ONLY_OUTCOME_STATUSES.includes(outcome.status))
  )
    fail("outcome.status");
  if (
    ["succeeded", "failed"].includes(outcome.status) &&
    outcome.receipt === null
  )
    fail("outcome.receipt");
  if (outcome.receipt !== null) {
    const receipt = parseReceipt(outcome.receipt);
    if (
      receipt.actionId !== ref.id ||
      receipt.revision !== outcome.authorizedRevision ||
      receipt.digest !== outcome.authorizedDigest
    )
      fail("outcome.receipt");
    if (!receiptFitsStatus(receipt, outcome.status)) fail("outcome.receipt");
    if (
      !v2 &&
      ("reason" in receipt || !V1_RECEIPT_KINDS.includes(receipt.kind))
    )
      fail("outcome.receipt");
  }
  if (
    [
      "authorized",
      "declined",
      "submitted",
      "unknown",
      ...V2_ONLY_OUTCOME_STATUSES,
    ].includes(outcome.status) &&
    outcome.receipt !== null
  )
    fail("outcome.receipt");
  num(outcome.occurredAt, "outcome.occurredAt");
  return outcome;
}

export function parseCapabilities(input) {
  const data = object(input, "capabilities");
  exact(
    data,
    [
      "version",
      "accountId",
      "oracleDid",
      "network",
      "resourceOrigin",
      "operations",
      "forms",
      "transfer",
    ],
    "capabilities",
  );
  if (
    ![CAPABILITIES_VERSION_V1, CAPABILITIES_VERSION_V2].includes(data.version)
  )
    fail("capabilities.version");
  str(data.accountId, "capabilities.accountId", 1, 100);
  str(data.oracleDid, "capabilities.oracleDid", 1, 200);
  if (
    data.network !== null &&
    !NETWORKS.includes(data.network)
  )
    fail("capabilities.network");
  if (data.resourceOrigin !== null) {
    const url = new URL(
      str(data.resourceOrigin, "capabilities.resourceOrigin", 1, 2000),
    );
    if (
      url.protocol !== "https:" ||
      url.pathname !== "/" ||
      url.search ||
      url.hash
    )
      fail("capabilities.resourceOrigin");
  }
  if (
    !Array.isArray(data.operations) ||
    new Set(data.operations).size !== data.operations.length ||
    data.operations.some(
      (kind) =>
        !(
          data.version === CAPABILITIES_VERSION_V1
            ? V1_OPERATION_KINDS
            : operationKinds
        ).includes(kind),
    )
  )
    fail("capabilities.operations");
  if (data.transfer !== null) {
    object(data.transfer, "capabilities.transfer");
    exact(
      data.transfer,
      ["maxAmountUixo", "maxFeeUixo"],
      "capabilities.transfer",
    );
    pattern(
      data.transfer.maxAmountUixo,
      /^[1-9][0-9]{0,19}$/,
      "capabilities.transfer.maxAmountUixo",
    );
    pattern(
      data.transfer.maxFeeUixo,
      /^[1-9][0-9]{0,19}$/,
      "capabilities.transfer.maxFeeUixo",
    );
  }
  if (data.operations.includes("ixo.bank.send.v1") && data.transfer === null)
    fail("capabilities.transfer");
  if (!Array.isArray(data.forms)) fail("capabilities.forms");
  for (const form of data.forms) {
    object(form, "capabilities.form");
    exact(
      form,
      ["formId", "destination", "fields", "declaration"],
      "capabilities.form",
    );
    str(form.formId, "formId", 1, 120);
    str(form.destination, "destination", 1, 200);
    if (form.declaration !== null) str(form.declaration, "declaration", 1, 120);
    if (
      !Array.isArray(form.fields) ||
      form.fields.length < 1 ||
      form.fields.length > 20
    )
      fail("form.fields");
    const ids = new Set();
    for (const field of form.fields) {
      object(field, "field");
      exact(field, ["id", "label", "type", "required"], "field");
      pattern(field.id, FIELD, "field.id");
      str(field.label, "field.label", 1, 120);
      if (
        !["text", "email", "tel", "textarea"].includes(field.type) ||
        typeof field.required !== "boolean" ||
        ids.has(field.id)
      )
        fail("field");
      ids.add(field.id);
    }
  }
  return data;
}

const utf8 = (value, field) => {
  str(value, field, 0, 8192);
  if (
    new TextEncoder().encode(value).length > 8192 ||
    /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(
      value,
    )
  )
    fail(field);
  return value;
};
const nullableString = (v, f, max = 200) =>
  v === null ? null : str(v, f, 1, max);
const urlValue = (v) => {
  const u = new URL(str(v, "url", 1, 2000));
  if (
    (u.protocol !== "https:" &&
      !(
        u.protocol === "http:" &&
        ["localhost", "127.0.0.1"].includes(u.hostname)
      )) ||
    u.username ||
    u.password ||
    u.hash
  )
    fail("url");
  return v;
};
const nullableUrl = (v) => (v === null ? null : urlValue(v));
const scopeList = (v) => {
  if (!Array.isArray(v) || v.length > 30 || new Set(v).size !== v.length)
    fail("scopes");
  for (const s of v) str(s, "scope", 1, 300);
  return v;
};
const tuple = (v) => {
  pattern(v.actionId, ID, "actionId");
  num(v.revision, "revision");
  pattern(v.digest, HEX, "digest");
};
export function privateTextPath(actionId, filename) {
  pattern(actionId, ID, "actionId");
  if (
    typeof filename !== "string" ||
    filename.length > 80 ||
    !/^[A-Za-z0-9][A-Za-z0-9 _.-]*\.txt$/.test(filename) ||
    filename.includes("..") ||
    filename.endsWith(" .txt")
  )
    fail("filename");
  return `/${actionId}-${filename}`;
}
export function serviceForOperation(op) {
  const kind = typeof op === "string" ? op : op.kind;
  return kind.startsWith("gmail.")
    ? "gmail"
    : kind.startsWith("calendar.")
      ? "calendar"
      : kind.startsWith("vfs.")
        ? "vfs"
        : null;
}
const receiptKinds = {
  "form.submit.v1": "form.submission.v1",
  "ixo.bank.send.v1": "ixo.bank.send.v1",
  "statement.sign.v1": "statement.signed.v1",
  "gmail.connect.v1": "gmail.connected.v1",
  "gmail.disconnect.v1": "gmail.disconnected.v1",
  "gmail.message.send.v1": "gmail.message.accepted.v1",
  "calendar.connect.v1": "calendar.connected.v1",
  "calendar.disconnect.v1": "calendar.disconnected.v1",
  "calendar.event.create.v1": "calendar.event.created.v1",
  "vfs.access.request.v1": "vfs.access.requested.v1",
  "vfs.text.save.v1": "vfs.text.saved.v1",
};
export function assertReceiptForOperation(
  operation,
  receipt,
  status = "succeeded",
) {
  parseReceipt(receipt);
  if (
    ["succeeded", "failed"].includes(status) &&
    !receiptFitsStatus(receipt, status)
  )
    fail("operation receipt");
  if (
    status === "failed" &&
    receipt.kind === "service.failure.v1" &&
    receipt.service === serviceForOperation(operation)
  )
    return receipt;
  if (
    receiptKinds[operation.kind] !== receipt.kind ||
    receipt.kind === "service.failure.v1"
  )
    fail("operation receipt");
  // Every kind: the receipt must name the approved connection / target.
  if (
    "connectionId" in operation &&
    operation.connectionId !== null &&
    "connectionId" in receipt &&
    receipt.connectionId !== operation.connectionId
  )
    fail("receipt connection");
  if (
    "targetId" in operation &&
    "targetId" in receipt &&
    receipt.targetId !== operation.targetId
  )
    fail("receipt target");
  return receipt;
}
const p2ReceiptFields = {
  "statement.signed.v1": [
    "statementDigest",
    "proofDigest",
    "signerDid",
    "signedAt",
  ],
  "gmail.connected.v1": ["connectionId", "scopesDigest", "verifiedAt"],
  "gmail.disconnected.v1": [
    "connectionId",
    "localRevokedAt",
    "providerDisconnected",
    "verifiedAt",
  ],
  "gmail.message.accepted.v1": [
    "connectionId",
    "messageId",
    "contentDigest",
    "mimeDigest",
    "acceptedAt",
  ],
  "calendar.connected.v1": ["connectionId", "scopesDigest", "verifiedAt"],
  "calendar.disconnected.v1": [
    "connectionId",
    "localRevokedAt",
    "providerDisconnected",
    "verifiedAt",
  ],
  "calendar.event.created.v1": [
    "connectionId",
    "eventId",
    "eventDigest",
    "verifiedAt",
  ],
  "vfs.access.requested.v1": ["requestId", "targetId", "state", "requestedAt"],
  "vfs.text.saved.v1": [
    "fileId",
    "cid",
    "version",
    "contentDigest",
    "private",
    "verifiedAt",
  ],
  "service.failure.v1": ["service", "code", "failedAt"],
};
function parseP2Receipt(v) {
  exact(
    v,
    ["kind", "actionId", "revision", "digest", ...p2ReceiptFields[v.kind]],
    "receipt",
  );
  tuple(v);
  for (const k of p2ReceiptFields[v.kind]) {
    if (k.endsWith("Digest")) pattern(v[k], HEX, k);
    else if (k.endsWith("At") || k === "version") num(v[k], k);
    else if (k === "private") {
      if (v[k] !== true) fail(k);
    } else if (k === "providerDisconnected") {
      if (v[k] !== null && typeof v[k] !== "boolean") fail(k);
    } else str(v[k], k, 1, k === "cid" ? 200 : 200);
  }
  if (v.kind === "vfs.access.requested.v1" && v.state !== "pending_owner")
    fail("state");
  if (
    v.kind === "service.failure.v1" &&
    (!["calendar", "gmail", "vfs"].includes(v.service) ||
      ![
        "permission_denied",
        "changed",
        "rejected",
        "conflict",
        // 0.4.0: expired before anything was sent; service unavailable.
        "expired",
        "unavailable",
      ].includes(
        v.code,
      ))
  )
    fail("service failure");
  return v;
}
export function parseResourceDescriptor(input) {
  const v = object(input, "resource");
  exact(
    v,
    [
      "id",
      "title",
      "ownerDid",
      "url",
      "version",
      "contentDigest",
      "cid",
      "fileId",
    ],
    "resource",
  );
  for (const k of ["id", "title", "ownerDid", "version", "cid", "fileId"])
    str(v[k], k, 1, 200);
  pattern(v.contentDigest, HEX, "contentDigest");
  urlValue(v.url);
  if (new URL(v.url).search) fail("resource.url");
  return v;
}
export function parseServiceAuthorization(input) {
  const v = object(input, "authorization");
  exact(
    v,
    [
      "version",
      "mode",
      "service",
      "hubOrigin",
      "accountId",
      "actionId",
      "ownerDid",
      "oracleDid",
      "bindingId",
      "bindingRevision",
      "consentVersion",
      "policyVersion",
      "revision",
      "digest",
      "network",
      "operation",
      "issuedAt",
      "expiresAt",
      "nonce",
    ],
    "authorization",
  );
  if (
    v.version !== "ixo.auth-authorization/1" ||
    !["prepare", "execute"].includes(v.mode) ||
    !["calendar", "gmail", "vfs"].includes(v.service) ||
    !SERVICE_NETWORKS.includes(v.network)
  )
    fail("authorization");
  tuple(v);
  for (const k of ["accountId", "bindingId", "consentVersion", "nonce"])
    str(v[k], k, 1, 100);
  for (const k of ["ownerDid", "oracleDid"]) str(v[k], k, 1, 200);
  for (const k of ["bindingRevision", "policyVersion", "issuedAt", "expiresAt"])
    num(v[k], k);
  if (v.expiresAt <= v.issuedAt) fail("expiresAt");
  urlValue(v.hubOrigin);
  if (new URL(v.hubOrigin).origin !== v.hubOrigin) fail("hubOrigin");
  parseOperation(v.operation);
  if (
    serviceForOperation(v.operation) !== v.service ||
    (v.mode === "prepare" &&
      !["calendar.connect.v1", "gmail.connect.v1"].includes(v.operation.kind))
  )
    fail("service operation");
  return v;
}
export function parseServiceCommand(input) {
  const v = object(input, "command");
  exact(
    v,
    ["authorization", "ownerInvocation", "subscriptionDelegation"],
    "command",
  );
  parseServiceAuthorization(v.authorization);
  str(v.ownerInvocation, "ownerInvocation", 1, 65536);
  if (v.subscriptionDelegation !== null)
    str(v.subscriptionDelegation, "subscriptionDelegation", 1, 65536);
  if (
    ["calendar", "gmail"].includes(v.authorization.service) &&
    v.subscriptionDelegation === null
  )
    fail("subscriptionDelegation");
  if (v.authorization.service === "vfs" && v.subscriptionDelegation !== null)
    fail("subscriptionDelegation");
  return v;
}
export function parseServicePreparation(input) {
  const v = object(input, "preparation");
  exact(
    v,
    [
      "version",
      "accountId",
      "actionId",
      "revision",
      "digest",
      "status",
      "operation",
      "continuationUrl",
    ],
    "preparation",
  );
  if (
    v.version !== "ixo.auth-preparation/1" ||
    !["pending", "ready", "unknown"].includes(v.status)
  )
    fail("preparation");
  tuple(v);
  str(v.accountId, "accountId", 1, 100);
  parseOperation(v.operation);
  if (!["calendar.connect.v1", "gmail.connect.v1"].includes(v.operation.kind))
    fail("preparation operation");
  nullableUrl(v.continuationUrl);
  if (
    v.status === "ready" &&
    (!v.operation.connectionId ||
      !v.operation.accountLabel ||
      !v.operation.scopes.length ||
      v.continuationUrl !== null)
  )
    fail("ready preparation");
  return v;
}
export function parseServiceResult(input) {
  const v = object(input, "service result");
  exact(
    v,
    [
      "version",
      "accountId",
      "actionId",
      "revision",
      "digest",
      "authorizationDigest",
      "sequence",
      "status",
      "receipt",
      "continuationUrl",
      "accountLabel",
      "resource",
      "checkedAt",
    ],
    "service result",
  );
  if (
    v.version !== "ixo.auth-service-result/1" ||
    !["pending", "succeeded", "failed", "unknown"].includes(v.status)
  )
    fail("service result");
  tuple(v);
  str(v.accountId, "accountId", 1, 100);
  pattern(v.authorizationDigest, HEX, "authorizationDigest");
  num(v.sequence, "sequence");
  num(v.checkedAt, "checkedAt");
  nullableUrl(v.continuationUrl);
  nullableString(v.accountLabel, "accountLabel");
  if (v.resource !== null) parseResourceDescriptor(v.resource);
  if (["pending", "unknown"].includes(v.status)) {
    if (v.receipt !== null) fail("receipt");
  } else {
    const r = parseReceipt(v.receipt);
    if (
      r.actionId !== v.actionId ||
      r.revision !== v.revision ||
      r.digest !== v.digest ||
      (v.status === "failed"
        ? r.kind !== "service.failure.v1"
        : r.kind === "service.failure.v1")
    )
      fail("receipt");
  }
  return v;
}
export function parseActionOptions(input) {
  const v = object(input, "options");
  exact(
    v,
    [
      "version",
      "accountId",
      "ownerDid",
      "bindingId",
      "bindingRevision",
      "connections",
      "targets",
      "resources",
    ],
    "options",
  );
  if (!["ixo.auth-options/1", "ixo.auth-options/2"].includes(v.version))
    fail("options.version");
  for (const k of ["accountId", "bindingId"]) str(v[k], k, 1, 100);
  str(v.ownerDid, "ownerDid");
  num(v.bindingRevision, "bindingRevision");
  for (const k of ["connections", "targets", "resources"])
    if (!Array.isArray(v[k]) || v[k].length > 100) fail(k);
  for (const c of v.connections) {
    object(c, "connection");
    exact(
      c,
      v.version === "ixo.auth-options/2"
        ? ["service", "id", "label", "scopes"]
        : ["id", "label", "scopes"],
      "connection",
    );
    if (
      v.version === "ixo.auth-options/2" &&
      !["calendar", "gmail"].includes(c.service)
    )
      fail("connection.service");
    str(c.id, "id", 1, 100);
    str(c.label, "label");
    scopeList(c.scopes);
  }
  for (const t of v.targets) {
    object(t, "target");
    exact(t, ["id", "title"], "target");
    str(t.id, "id", 1, 100);
    str(t.title, "title");
  }
  v.resources.forEach(parseResourceDescriptor);
  return v;
}
export const parseHubActionOptions = parseActionOptions;
export function parseStatementProofBody(input) {
  const v = object(input, "statement proof body");
  exact(
    v,
    [
      "version",
      "accountId",
      "actionId",
      "revision",
      "digest",
      "ownerDid",
      "network",
      "audience",
      "purpose",
      "statementDigest",
      "issuedAt",
      "nonce",
    ],
    "statement proof body",
  );
  if (
    v.version !== "ixo.statement-proof/1" ||
    !SERVICE_NETWORKS.includes(v.network)
  )
    fail("statement proof body");
  tuple(v);
  str(v.accountId, "accountId", 1, 100);
  str(v.ownerDid, "ownerDid");
  str(v.audience, "audience", 1, 2000);
  str(v.purpose, "purpose", 1, 120);
  pattern(v.statementDigest, HEX, "statementDigest");
  num(v.issuedAt, "issuedAt");
  str(v.nonce, "nonce", 1, 100);
  return v;
}
export function parseStatementProof(input) {
  const v = object(input, "statement proof");
  exact(v, ["body", "publicKey", "signature", "statement"], "statement proof");
  parseStatementProofBody(v.body);
  pattern(v.publicKey, /^[a-f0-9]{64}$/, "publicKey");
  pattern(v.signature, /^[a-f0-9]{128}$/, "signature");
  utf8(v.statement, "statement");
  return v;
}

function validCalendarInstant(value) {
  const parts =
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,3})?(?:Z|[+-](\d{2}):(\d{2}))$/.exec(
      value,
    );
  if (!parts) return false;
  const [, year, month, day, hour, minute, second, offsetHour, offsetMinute] =
    parts;
  const y = Number(year),
    m = Number(month),
    d = Number(day);
  const leap = y % 4 === 0 && (y % 100 !== 0 || y % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return (
    m >= 1 &&
    m <= 12 &&
    d >= 1 &&
    d <= days[m - 1] &&
    Number(hour) <= 23 &&
    Number(minute) <= 59 &&
    Number(second) <= 59 &&
    (offsetHour === undefined ||
      (Number(offsetHour) <= 23 && Number(offsetMinute) <= 59))
  );
}

/** Status rules shared by review views and outcomes. */
function receiptFitsStatus(receipt, status) {
  const bank = receipt.kind === "ixo.bank.send.v1";
  if (status === "succeeded")
    return bank
      ? receipt.code === 0 && receipt.height !== null && !("reason" in receipt)
      : receipt.kind !== "service.failure.v1";
  if (status === "failed") {
    if (receipt.kind === "service.failure.v1") return true;
    if (!bank) return false;
    if ("reason" in receipt) return true; // checked by parseReceipt
    return (
      receipt.code !== null && receipt.code !== 0 && receipt.height !== null
    );
  }
  return true;
}

/**
 * Re-express a v2 outcome for a v1 caller, or return null when v1 cannot
 * represent it (expired/cancelled, or a not-included bank receipt).
 */
export function outcomeForVersion(input, version) {
  const outcome = parseOutcome(input);
  if (version === OUTCOME_VERSION_V2)
    return { ...outcome, version: OUTCOME_VERSION_V2 };
  if (version !== OUTCOME_VERSION_V1) return fail("outcome.version");
  if (
    !V1_OUTCOME_STATUSES.includes(outcome.status) ||
    (outcome.receipt &&
      ("reason" in outcome.receipt ||
        !V1_RECEIPT_KINDS.includes(outcome.receipt.kind)))
  )
    return null;
  return parseOutcome({ ...outcome, version: OUTCOME_VERSION_V1 });
}
