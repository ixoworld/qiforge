export type FormField = {
  id: string;
  label: string;
  type: "text" | "email" | "tel" | "textarea";
  required: boolean;
  value: string;
  source: "user" | "record" | "suggestion";
};
export type ActionOperationV1 =
  | P2Operation
  | {
      kind: "form.submit.v1";
      formId: string;
      destination: string;
      fields: FormField[];
      declaration: string | null;
    }
  | {
      kind: "ixo.bank.send.v1";
      chainId: string;
      network: "ixo testnet" | "ixo devnet";
      fromAddress: string;
      toAddress: string;
      amountBaseUnits: string;
      denom: "uixo";
      feeBaseUnits: string;
      memo: string;
    }
  | {
      kind: "resource.read.v1";
      resourceId: string;
      ownerDid: string;
      url: string;
      version: string;
      contentDigest: string;
    };
export type ActionReferenceV1 = {
  version: "ixo.auth-action/1";
  id: string;
  accountId: string;
  bindingId: string;
  bindingRevision: number;
  revision: number;
  digest: string;
  url: string;
  expiresAt: number;
  title: string;
};
export type ActionReceiptV1 =
  | P2Receipt
  | {
      kind: "form.submission.v1";
      actionId: string;
      revision: number;
      digest: string;
      valuesDigest: string;
      submittedAt: number;
      submissionId: string;
    }
  | {
      kind: "ixo.bank.send.v1";
      actionId: string;
      revision: number;
      digest: string;
      chainId: string;
      txHash: string;
      height: number | null;
      code: number | null;
    };
export type ActionOutcomeV1 = {
  version: "ixo.auth-outcome/1";
  eventId: string;
  reference: ActionReferenceV1;
  ownerDid: string;
  authorizedRevision: number;
  authorizedDigest: string;
  sequence: number;
  status:
    | "authorized"
    | "declined"
    | "submitted"
    | "succeeded"
    | "failed"
    | "unknown";
  receipt: ActionReceiptV1 | null;
  occurredAt: number;
};
export type ActionReviewView = {
  reference: ActionReferenceV1;
  requester: string;
  operation: ActionOperationV1;
  reviewStatus:
    | "prepared"
    | "superseded"
    | "declined"
    | "expired"
    | "revoked"
    | "signing"
    | "authorized";
  operationStatus:
    | "awaiting_authorization"
    | "admitted"
    | "submitted"
    | "succeeded"
    | "failed"
    | "requires_review"
    | "unknown";
  revision: number;
  digest: string;
  canEdit: boolean;
  canApprove: boolean;
  canSign: boolean;
  receipt: ActionReceiptV1 | null;
  signedTxHash: string | null;
  resourceUrl: string | null;
  chatUrl: string;
  service?: {
    continuationUrl: string | null;
    accountLabel: string | null;
    resource: ResourceDescriptor | null;
  } | null;
};
export type ActionCapabilitiesV1 = {
  version: "ixo.auth-capabilities/1";
  accountId: string;
  oracleDid: string;
  network: "ixo testnet" | "ixo devnet" | null;
  resourceOrigin: string | null;
  operations: ActionOperationV1["kind"][];
  forms: {
    formId: string;
    destination: string;
    fields: Omit<FormField, "value" | "source">[];
    declaration: string | null;
  }[];
  transfer: { maxAmountUixo: string; maxFeeUixo: string } | null;
};
export declare function canonicalJson(value: unknown): string;
export declare function digestOf(value: unknown): Promise<string>;
export declare function parseOperation(value: unknown): ActionOperationV1;
export declare function parseReference(value: unknown): ActionReferenceV1;
export declare function assertHubReferenceUrl(
  value: unknown,
  configuredOrigin: string,
): ActionReferenceV1;
export declare function parseReceipt(value: unknown): ActionReceiptV1;
export declare function parseOutcome(value: unknown): ActionOutcomeV1;
export declare function parseReviewView(value: unknown): ActionReviewView;
export declare function parseCapabilities(value: unknown): ActionCapabilitiesV1;

export type P2Operation =
  | {
      kind: "statement.sign.v1";
      statement: string;
      purpose: string;
      audienceId: string;
    }
  | {
      kind: "calendar.connect.v1";
      purpose: string;
      connectionId: string | null;
      accountLabel: string | null;
      scopes: string[];
    }
  | {
      kind: "calendar.disconnect.v1";
      connectionId: string;
      accountLabel: string;
    }
  | {
      kind: "calendar.event.create.v1";
      connectionId: string;
      accountLabel: string;
      calendarId: "primary";
      title: string;
      description: string;
      startsAt: string;
      endsAt: string;
      timeZone: string;
    }
  | {
      kind: "vfs.access.request.v1";
      targetId: string;
      title: string;
      ability: "read";
      purpose: string;
    }
  | { kind: "vfs.text.save.v1"; filename: string; text: string };
export type ActionOperation = ActionOperationV1;
export type ActionReceipt = ActionReceiptV1;
export type ServiceName = "calendar" | "vfs";
export type ReceiptTuple = {
  actionId: string;
  revision: number;
  digest: string;
};
export type P2Receipt = ReceiptTuple &
  (
    | {
        kind: "statement.signed.v1";
        statementDigest: string;
        proofDigest: string;
        signerDid: string;
        signedAt: number;
      }
    | {
        kind: "calendar.connected.v1";
        connectionId: string;
        scopesDigest: string;
        verifiedAt: number;
      }
    | {
        kind: "calendar.disconnected.v1";
        connectionId: string;
        localRevokedAt: number;
        providerDisconnected: boolean | null;
        verifiedAt: number;
      }
    | {
        kind: "calendar.event.created.v1";
        connectionId: string;
        eventId: string;
        eventDigest: string;
        verifiedAt: number;
      }
    | {
        kind: "vfs.access.requested.v1";
        requestId: string;
        targetId: string;
        state: "pending_owner";
        requestedAt: number;
      }
    | {
        kind: "vfs.text.saved.v1";
        fileId: string;
        cid: string;
        version: number;
        contentDigest: string;
        private: true;
        verifiedAt: number;
      }
    | {
        kind: "service.failure.v1";
        service: ServiceName;
        code: "permission_denied" | "changed" | "rejected" | "conflict";
        failedAt: number;
      }
  );
export type ResourceDescriptor = {
  id: string;
  title: string;
  ownerDid: string;
  url: string;
  version: string;
  contentDigest: string;
  cid: string;
  fileId: string;
};
export type ServiceAuthorizationV1 = ReceiptTuple & {
  version: "ixo.auth-authorization/1";
  mode: "prepare" | "execute";
  service: ServiceName;
  hubOrigin: string;
  accountId: string;
  ownerDid: string;
  oracleDid: string;
  bindingId: string;
  bindingRevision: number;
  consentVersion: string;
  policyVersion: number;
  network: "devnet" | "testnet";
  operation: ActionOperationV1;
  issuedAt: number;
  expiresAt: number;
  nonce: string;
};
export type ServiceCommand = {
  authorization: ServiceAuthorizationV1;
  ownerInvocation: string;
  subscriptionDelegation: string | null;
};
export type ServiceCommandV1 = ServiceCommand;
export type ServicePreparationV1 = ReceiptTuple & {
  version: "ixo.auth-preparation/1";
  accountId: string;
  status: "pending" | "ready" | "unknown";
  operation: Extract<ActionOperationV1, { kind: "calendar.connect.v1" }>;
  continuationUrl: string | null;
};
export type ServiceResultV1 = ReceiptTuple & {
  version: "ixo.auth-service-result/1";
  accountId: string;
  authorizationDigest: string;
  sequence: number;
  status: "pending" | "succeeded" | "failed" | "unknown";
  receipt: ActionReceiptV1 | null;
  continuationUrl: string | null;
  accountLabel: string | null;
  resource: ResourceDescriptor | null;
  checkedAt: number;
};
export type HubActionOptionsV1 = {
  version: "ixo.auth-options/1";
  accountId: string;
  ownerDid: string;
  bindingId: string;
  bindingRevision: number;
  connections: { id: string; label: string; scopes: string[] }[];
  targets: { id: string; title: string }[];
  resources: ResourceDescriptor[];
};
export type StatementProofBody = ReceiptTuple & {
  version: "ixo.statement-proof/1";
  accountId: string;
  ownerDid: string;
  network: "devnet" | "testnet";
  audience: string;
  purpose: string;
  statementDigest: string;
  issuedAt: number;
  nonce: string;
};
export type StatementProof = {
  body: StatementProofBody;
  publicKey: string;
  signature: string;
  statement: string;
};
export declare const operationKinds: readonly [
  ActionOperationV1["kind"],
  ...ActionOperationV1["kind"][],
];
export declare const operationJsonSchema: {
  readonly $schema: string;
  readonly oneOf: Record<string, unknown>[];
};
export declare function privateTextPath(
  actionId: string,
  filename: string,
): string;
export declare function serviceForOperation(
  operation: ActionOperationV1 | ActionOperationV1["kind"],
): ServiceName | null;
export declare function assertReceiptForOperation(
  operation: ActionOperationV1,
  receipt: ActionReceiptV1,
  status?: string,
): ActionReceiptV1;
export declare function parseResourceDescriptor(
  input: unknown,
): ResourceDescriptor;
export declare function parseServiceAuthorization(
  input: unknown,
): ServiceAuthorizationV1;
export declare function parseServiceCommand(input: unknown): ServiceCommand;
export declare function parseServicePreparation(
  input: unknown,
): ServicePreparationV1;
export declare function parseServiceResult(input: unknown): ServiceResultV1;
export declare function parseActionOptions(input: unknown): HubActionOptionsV1;
export declare const parseHubActionOptions: typeof parseActionOptions;
export declare function parseStatementProofBody(
  input: unknown,
): StatementProofBody;
export declare function parseStatementProof(input: unknown): StatementProof;
