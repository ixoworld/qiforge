const string = (minLength = 1, maxLength = 200) => ({
  type: "string",
  minLength,
  maxLength,
});
const enumeration = (...values) => ({ enum: values });
const nullable = (schema) => ({ anyOf: [schema, { type: "null" }] });
const object = (properties) => ({
  type: "object",
  properties,
  required: Object.keys(properties),
  additionalProperties: false,
});
const fields = object({
  id: { ...string(1, 40), pattern: "^[a-z][a-z0-9_]{0,39}$" },
  label: string(1, 120),
  type: enumeration("text", "email", "tel", "textarea"),
  required: { type: "boolean" },
  value: string(0, 1000),
  source: enumeration("user", "record", "suggestion"),
});
const scopes = {
  type: "array",
  items: string(1, 300),
  maxItems: 30,
  uniqueItems: true,
};
const instant = {
  ...string(20, 40),
  pattern:
    "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d{1,3})?(?:Z|[+-]\\d{2}:\\d{2})$",
};
const hex = { ...string(64, 64), pattern: "^[a-f0-9]{64}$" };
const registry = {
  "form.submit.v1": {
    formId: string(1, 120),
    destination: string(1, 200),
    fields: { type: "array", items: fields, minItems: 1, maxItems: 20 },
    declaration: nullable(string(1, 120)),
  },
  "ixo.bank.send.v1": {
    chainId: string(1, 100),
    network: enumeration("ixo testnet", "ixo devnet"),
    fromAddress: string(),
    toAddress: string(),
    amountBaseUnits: { ...string(), pattern: "^[1-9][0-9]*$" },
    denom: { const: "uixo" },
    feeBaseUnits: { ...string(), pattern: "^(0|[1-9][0-9]*)$" },
    memo: string(0, 256),
  },
  "resource.read.v1": {
    resourceId: string(),
    ownerDid: string(),
    url: string(1, 2000),
    version: string(),
    contentDigest: hex,
  },
  "statement.sign.v1": {
    statement: string(0, 8192),
    purpose: string(1, 120),
    audienceId: string(1, 100),
  },
  "calendar.connect.v1": {
    purpose: string(1, 120),
    connectionId: nullable(string(1, 100)),
    accountLabel: nullable(string()),
    scopes,
  },
  "calendar.disconnect.v1": {
    connectionId: string(1, 100),
    accountLabel: string(),
  },
  "calendar.event.create.v1": {
    connectionId: string(1, 100),
    accountLabel: string(),
    calendarId: { const: "primary" },
    title: string(1, 120),
    description: string(0, 2000),
    startsAt: instant,
    endsAt: instant,
    timeZone: string(1, 100),
  },
  "vfs.access.request.v1": {
    targetId: string(1, 100),
    title: string(),
    ability: { const: "read" },
    purpose: string(1, 500),
  },
  "vfs.text.save.v1": {
    filename: {
      ...string(5, 80),
      pattern: "^[A-Za-z0-9][A-Za-z0-9 _.-]*\\.txt$",
    },
    text: string(0, 8192),
  },
};
export const operationKinds = Object.freeze(Object.keys(registry));
export const operationJsonSchema = Object.freeze({
  $schema: "https://json-schema.org/draft/2020-12/schema",
  oneOf: Object.entries(registry).map(([kind, properties]) =>
    object({ kind: { const: kind }, ...properties }),
  ),
});
function matches(value, schema) {
  if (schema.anyOf) return schema.anyOf.some((s) => matches(value, s));
  if ("const" in schema) return value === schema.const;
  if (schema.enum) return schema.enum.includes(value);
  if (schema.type === "null") return value === null;
  if (schema.type === "boolean") return typeof value === "boolean";
  if (schema.type === "string")
    return (
      typeof value === "string" &&
      value.length >= schema.minLength &&
      value.length <= schema.maxLength &&
      (!schema.pattern || new RegExp(schema.pattern).test(value))
    );
  if (schema.type === "array")
    return (
      Array.isArray(value) &&
      value.length >= (schema.minItems ?? 0) &&
      value.length <= schema.maxItems &&
      (!schema.uniqueItems || new Set(value).size === value.length) &&
      value.every((v) => matches(v, schema.items))
    );
  if (schema.type === "object")
    return (
      value !== null &&
      typeof value === "object" &&
      !Array.isArray(value) &&
      Object.keys(value).every((k) => k in schema.properties) &&
      schema.required.every(
        (k) =>
          Object.hasOwn(value, k) && matches(value[k], schema.properties[k]),
      )
    );
  return false;
}
export function validateOperationSchema(value) {
  const schema = operationJsonSchema.oneOf.find(
    (s) => s.properties.kind.const === value.kind,
  );
  if (!schema || !matches(value, schema))
    throw new TypeError("Invalid operation");
}
