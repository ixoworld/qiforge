const ID = /^[A-Za-z0-9_-]{32}$/;
const HEX = /^[a-f0-9]{64}$/;
const ADDRESS = /^ixo1[023456789acdefghjklmnpqrstuvwxyz]{38,59}$/;
const INT = /^(0|[1-9][0-9]*)$/;
const FIELD = /^[a-z][a-z0-9_]{0,39}$/;
const fail = (field) => {
  throw new TypeError(`Invalid ${field}`);
};
const object = (value, field) =>
  value && typeof value === "object" && !Array.isArray(value)
    ? value
    : fail(field);
const exact = (value, keys, field) => {
  for (const key of Object.keys(value)) if (!keys.includes(key)) fail(field);
};
const str = (value, field, min = 1, max = 200) =>
  typeof value === "string" && value.length >= min && value.length <= max
    ? value
    : fail(field);
const num = (value, field) =>
  Number.isSafeInteger(value) && value > 0 ? value : fail(field);
const pattern = (value, regex, field) =>
  regex.test(str(value, field)) ? value : fail(field);

export function canonicalJson(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value))
    return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (
    value &&
    typeof value === "object" &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    const keys = Object.keys(value).sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return fail("canonical JSON");
}

export async function digestOf(value) {
  const bytes = new TextEncoder().encode(canonicalJson(value));
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}

export function parseOperation(input) {
  const op = object(input, "operation");
  if (op.kind === "form.submit.v1") {
    exact(
      op,
      ["kind", "formId", "destination", "fields", "declaration"],
      "operation",
    );
    str(op.formId, "formId", 1, 120);
    str(op.destination, "destination", 1, 200);
    if (
      !Array.isArray(op.fields) ||
      op.fields.length < 1 ||
      op.fields.length > 20
    )
      fail("fields");
    const ids = new Set();
    for (const field of op.fields) {
      object(field, "field");
      exact(
        field,
        ["id", "label", "type", "required", "value", "source"],
        "field",
      );
      pattern(field.id, FIELD, "field.id");
      if (ids.has(field.id)) fail("duplicate field");
      ids.add(field.id);
      str(field.label, "field.label", 1, 120);
      if (!["text", "email", "tel", "textarea"].includes(field.type))
        fail("field.type");
      if (typeof field.required !== "boolean") fail("field.required");
      str(field.value, "field.value", 0, 1000);
      if (!["user", "record", "suggestion"].includes(field.source))
        fail("field.source");
    }
    if (op.declaration !== null) str(op.declaration, "declaration", 1, 120);
    return op;
  }
  if (op.kind === "ixo.bank.send.v1") {
    exact(
      op,
      [
        "kind",
        "chainId",
        "network",
        "fromAddress",
        "toAddress",
        "amountBaseUnits",
        "denom",
        "feeBaseUnits",
        "memo",
      ],
      "operation",
    );
    str(op.chainId, "chainId", 1, 100);
    if (!["ixo testnet", "ixo devnet"].includes(op.network)) fail("network");
    pattern(op.fromAddress, ADDRESS, "fromAddress");
    pattern(op.toAddress, ADDRESS, "toAddress");
    if (op.fromAddress === op.toAddress) fail("self transfer");
    pattern(op.amountBaseUnits, INT, "amountBaseUnits");
    if (op.amountBaseUnits === "0") fail("amountBaseUnits");
    if (op.denom !== "uixo") fail("denom");
    pattern(op.feeBaseUnits, INT, "feeBaseUnits");
    str(op.memo, "memo", 0, 256);
    return op;
  }
  if (op.kind === "resource.read.v1") {
    exact(
      op,
      ["kind", "resourceId", "ownerDid", "url", "version", "contentDigest"],
      "operation",
    );
    str(op.resourceId, "resourceId", 1, 200);
    str(op.ownerDid, "ownerDid", 1, 200);
    const url = new URL(str(op.url, "resource.url", 1, 2000));
    if (url.protocol !== "https:" || url.username || url.password || url.hash)
      fail("resource.url");
    str(op.version, "resource.version", 1, 200);
    pattern(op.contentDigest, HEX, "resource.contentDigest");
    return op;
  }
  return fail("operation.kind");
}

export function parseReference(input) {
  const ref = object(input, "reference");
  exact(
    ref,
    [
      "version",
      "id",
      "accountId",
      "bindingId",
      "bindingRevision",
      "revision",
      "digest",
      "url",
      "expiresAt",
      "title",
    ],
    "reference",
  );
  if (ref.version !== "ixo.auth-action/1") fail("reference.version");
  pattern(ref.id, ID, "reference.id");
  str(ref.accountId, "reference.accountId", 1, 100);
  str(ref.bindingId, "reference.bindingId", 1, 100);
  num(ref.bindingRevision, "reference.bindingRevision");
  num(ref.revision, "reference.revision");
  pattern(ref.digest, HEX, "reference.digest");
  const url = new URL(str(ref.url, "reference.url", 1, 2000));
  if (
    !(
      url.protocol === "https:" ||
      (url.protocol === "http:" && url.hostname === "localhost")
    ) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    url.pathname !== `/a/${ref.id}`
  )
    fail("reference.url");
  num(ref.expiresAt, "reference.expiresAt");
  str(ref.title, "reference.title", 1, 80);
  return ref;
}

export function assertHubReferenceUrl(input, configuredOrigin) {
  const ref = parseReference(input);
  const configured = new URL(configuredOrigin);
  if (
    !(
      configured.protocol === "https:" ||
      (configured.protocol === "http:" && configured.hostname === "localhost")
    ) ||
    configured.pathname !== "/" ||
    configured.search ||
    configured.hash ||
    new URL(ref.url).origin !== configured.origin
  )
    fail("reference.url.origin");
  return ref;
}

export function parseReceipt(input) {
  const receipt = object(input, "receipt");
  if (receipt.kind === "form.submission.v1") {
    exact(
      receipt,
      [
        "kind",
        "actionId",
        "revision",
        "digest",
        "valuesDigest",
        "submittedAt",
        "submissionId",
      ],
      "receipt",
    );
    pattern(receipt.actionId, ID, "receipt.actionId");
    num(receipt.revision, "receipt.revision");
    pattern(receipt.digest, HEX, "receipt.digest");
    pattern(receipt.valuesDigest, HEX, "receipt.valuesDigest");
    num(receipt.submittedAt, "receipt.submittedAt");
    str(receipt.submissionId, "receipt.submissionId", 1, 100);
    return receipt;
  }
  if (receipt.kind === "ixo.bank.send.v1") {
    exact(
      receipt,
      [
        "kind",
        "actionId",
        "revision",
        "digest",
        "chainId",
        "txHash",
        "height",
        "code",
      ],
      "receipt",
    );
    pattern(receipt.actionId, ID, "receipt.actionId");
    num(receipt.revision, "receipt.revision");
    pattern(receipt.digest, HEX, "receipt.digest");
    str(receipt.chainId, "receipt.chainId", 1, 100);
    pattern(receipt.txHash, HEX, "receipt.txHash");
    if (receipt.height !== null) num(receipt.height, "receipt.height");
    if (
      receipt.code !== null &&
      (!Number.isSafeInteger(receipt.code) || receipt.code < 0)
    )
      fail("receipt.code");
    return receipt;
  }
  return fail("receipt.kind");
}

export function parseReviewView(input) {
  const view = object(input, "view");
  exact(
    view,
    [
      "reference",
      "requester",
      "operation",
      "reviewStatus",
      "operationStatus",
      "revision",
      "digest",
      "canEdit",
      "canApprove",
      "canSign",
      "receipt",
      "signedTxHash",
      "resourceUrl",
      "chatUrl",
    ],
    "view",
  );
  parseReference(view.reference);
  str(view.requester, "view.requester", 1, 120);
  parseOperation(view.operation);
  if (
    ![
      "prepared",
      "superseded",
      "declined",
      "expired",
      "revoked",
      "signing",
      "authorized",
    ].includes(view.reviewStatus)
  )
    fail("view.reviewStatus");
  if (
    ![
      "awaiting_authorization",
      "admitted",
      "submitted",
      "succeeded",
      "failed",
      "requires_review",
      "unknown",
    ].includes(view.operationStatus)
  )
    fail("view.operationStatus");
  num(view.revision, "view.revision");
  pattern(view.digest, HEX, "view.digest");
  for (const key of ["canEdit", "canApprove", "canSign"])
    if (typeof view[key] !== "boolean") fail(`view.${key}`);
  if (view.receipt !== null) {
    const receipt = parseReceipt(view.receipt);
    if (
      receipt.actionId !== view.reference.id ||
      receipt.revision !== view.revision ||
      receipt.digest !== view.digest
    )
      fail("view.receipt");
    if (
      view.operation.kind === "form.submit.v1" &&
      receipt.kind !== "form.submission.v1"
    )
      fail("view.receipt");
    if (
      view.operation.kind === "ixo.bank.send.v1" &&
      receipt.kind !== "ixo.bank.send.v1"
    )
      fail("view.receipt");
    if (
      view.operationStatus === "succeeded" &&
      receipt.kind === "ixo.bank.send.v1" &&
      (receipt.code !== 0 || receipt.height === null)
    )
      fail("view.receipt");
    if (
      view.operationStatus === "failed" &&
      (receipt.kind !== "ixo.bank.send.v1" ||
        receipt.code === null ||
        receipt.code === 0 ||
        receipt.height === null)
    )
      fail("view.receipt");
  }
  if (
    ["succeeded", "failed"].includes(view.operationStatus) &&
    view.receipt === null
  )
    fail("view.receipt");
  if (view.signedTxHash !== null)
    pattern(view.signedTxHash, HEX, "view.signedTxHash");
  if (view.resourceUrl !== null) {
    const url = new URL(str(view.resourceUrl, "view.resourceUrl", 1, 2000));
    if (
      !(
        url.protocol === "https:" ||
        (url.protocol === "http:" && url.hostname === "localhost")
      ) ||
      url.username ||
      url.password ||
      url.hash
    )
      fail("view.resourceUrl");
  }
  const chat = new URL(str(view.chatUrl, "view.chatUrl", 1, 2000));
  if (chat.protocol !== "https:" || chat.username || chat.password)
    fail("view.chatUrl");
  return view;
}

export function parseOutcome(input) {
  const outcome = object(input, "outcome");
  exact(
    outcome,
    [
      "version",
      "eventId",
      "reference",
      "ownerDid",
      "authorizedRevision",
      "authorizedDigest",
      "sequence",
      "status",
      "receipt",
      "occurredAt",
    ],
    "outcome",
  );
  if (outcome.version !== "ixo.auth-outcome/1") fail("outcome.version");
  str(outcome.eventId, "outcome.eventId", 1, 100);
  const ref = parseReference(outcome.reference);
  str(outcome.ownerDid, "outcome.ownerDid", 1, 200);
  num(outcome.authorizedRevision, "outcome.authorizedRevision");
  pattern(outcome.authorizedDigest, HEX, "outcome.authorizedDigest");
  num(outcome.sequence, "outcome.sequence");
  if (
    ![
      "authorized",
      "declined",
      "submitted",
      "succeeded",
      "failed",
      "unknown",
    ].includes(outcome.status)
  )
    fail("outcome.status");
  if (
    ["succeeded", "failed"].includes(outcome.status) &&
    outcome.receipt === null
  )
    fail("outcome.receipt");
  if (outcome.receipt !== null) {
    const receipt = parseReceipt(outcome.receipt);
    if (
      receipt.actionId !== ref.id ||
      receipt.revision !== outcome.authorizedRevision ||
      receipt.digest !== outcome.authorizedDigest
    )
      fail("outcome.receipt");
    if (
      outcome.status === "succeeded" &&
      receipt.kind === "ixo.bank.send.v1" &&
      (receipt.code !== 0 || receipt.height === null)
    )
      fail("outcome.receipt");
    if (
      outcome.status === "failed" &&
      (receipt.kind !== "ixo.bank.send.v1" ||
        receipt.code === null ||
        receipt.code === 0 ||
        receipt.height === null)
    )
      fail("outcome.receipt");
  }
  if (
    ["authorized", "declined", "submitted", "unknown"].includes(
      outcome.status,
    ) &&
    outcome.receipt !== null
  )
    fail("outcome.receipt");
  num(outcome.occurredAt, "outcome.occurredAt");
  return outcome;
}

export function parseCapabilities(input) {
  const data = object(input, "capabilities");
  exact(
    data,
    [
      "version",
      "accountId",
      "oracleDid",
      "network",
      "resourceOrigin",
      "operations",
      "forms",
      "transfer",
    ],
    "capabilities",
  );
  if (data.version !== "ixo.auth-capabilities/1") fail("capabilities.version");
  str(data.accountId, "capabilities.accountId", 1, 100);
  str(data.oracleDid, "capabilities.oracleDid", 1, 200);
  if (
    data.network !== null &&
    !["ixo testnet", "ixo devnet"].includes(data.network)
  )
    fail("capabilities.network");
  if (data.resourceOrigin !== null) {
    const url = new URL(
      str(data.resourceOrigin, "capabilities.resourceOrigin", 1, 2000),
    );
    if (
      url.protocol !== "https:" ||
      url.pathname !== "/" ||
      url.search ||
      url.hash
    )
      fail("capabilities.resourceOrigin");
  }
  if (
    !Array.isArray(data.operations) ||
    new Set(data.operations).size !== data.operations.length ||
    data.operations.some(
      (kind) =>
        !["form.submit.v1", "ixo.bank.send.v1", "resource.read.v1"].includes(
          kind,
        ),
    )
  )
    fail("capabilities.operations");
  if (data.transfer !== null) {
    object(data.transfer, "capabilities.transfer");
    exact(
      data.transfer,
      ["maxAmountUixo", "maxFeeUixo"],
      "capabilities.transfer",
    );
    pattern(
      data.transfer.maxAmountUixo,
      /^[1-9][0-9]{0,19}$/,
      "capabilities.transfer.maxAmountUixo",
    );
    pattern(
      data.transfer.maxFeeUixo,
      /^[1-9][0-9]{0,19}$/,
      "capabilities.transfer.maxFeeUixo",
    );
  }
  if (data.operations.includes("ixo.bank.send.v1") && data.transfer === null)
    fail("capabilities.transfer");
  if (!Array.isArray(data.forms)) fail("capabilities.forms");
  for (const form of data.forms) {
    object(form, "capabilities.form");
    exact(
      form,
      ["formId", "destination", "fields", "declaration"],
      "capabilities.form",
    );
    str(form.formId, "formId", 1, 120);
    str(form.destination, "destination", 1, 200);
    if (form.declaration !== null) str(form.declaration, "declaration", 1, 120);
    if (
      !Array.isArray(form.fields) ||
      form.fields.length < 1 ||
      form.fields.length > 20
    )
      fail("form.fields");
    const ids = new Set();
    for (const field of form.fields) {
      object(field, "field");
      exact(field, ["id", "label", "type", "required"], "field");
      pattern(field.id, FIELD, "field.id");
      str(field.label, "field.label", 1, 120);
      if (
        !["text", "email", "tel", "textarea"].includes(field.type) ||
        typeof field.required !== "boolean" ||
        ids.has(field.id)
      )
        fail("field");
      ids.add(field.id);
    }
  }
  return data;
}
