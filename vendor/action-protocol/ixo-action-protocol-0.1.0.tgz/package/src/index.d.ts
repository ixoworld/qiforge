export type FormField = {
  id: string;
  label: string;
  type: "text" | "email" | "tel" | "textarea";
  required: boolean;
  value: string;
  source: "user" | "record" | "suggestion";
};
export type ActionOperationV1 =
  | {
      kind: "form.submit.v1";
      formId: string;
      destination: string;
      fields: FormField[];
      declaration: string | null;
    }
  | {
      kind: "ixo.bank.send.v1";
      chainId: string;
      network: "ixo testnet" | "ixo devnet";
      fromAddress: string;
      toAddress: string;
      amountBaseUnits: string;
      denom: "uixo";
      feeBaseUnits: string;
      memo: string;
    }
  | {
      kind: "resource.read.v1";
      resourceId: string;
      ownerDid: string;
      url: string;
      version: string;
      contentDigest: string;
    };
export type ActionReferenceV1 = {
  version: "ixo.auth-action/1";
  id: string;
  accountId: string;
  bindingId: string;
  bindingRevision: number;
  revision: number;
  digest: string;
  url: string;
  expiresAt: number;
  title: string;
};
export type ActionReceiptV1 =
  | {
      kind: "form.submission.v1";
      actionId: string;
      revision: number;
      digest: string;
      valuesDigest: string;
      submittedAt: number;
      submissionId: string;
    }
  | {
      kind: "ixo.bank.send.v1";
      actionId: string;
      revision: number;
      digest: string;
      chainId: string;
      txHash: string;
      height: number | null;
      code: number | null;
    };
export type ActionOutcomeV1 = {
  version: "ixo.auth-outcome/1";
  eventId: string;
  reference: ActionReferenceV1;
  ownerDid: string;
  authorizedRevision: number;
  authorizedDigest: string;
  sequence: number;
  status:
    | "authorized"
    | "declined"
    | "submitted"
    | "succeeded"
    | "failed"
    | "unknown";
  receipt: ActionReceiptV1 | null;
  occurredAt: number;
};
export type ActionReviewView = {
  reference: ActionReferenceV1;
  requester: string;
  operation: ActionOperationV1;
  reviewStatus:
    | "prepared"
    | "superseded"
    | "declined"
    | "expired"
    | "revoked"
    | "signing"
    | "authorized";
  operationStatus:
    | "awaiting_authorization"
    | "admitted"
    | "submitted"
    | "succeeded"
    | "failed"
    | "requires_review"
    | "unknown";
  revision: number;
  digest: string;
  canEdit: boolean;
  canApprove: boolean;
  canSign: boolean;
  receipt: ActionReceiptV1 | null;
  signedTxHash: string | null;
  resourceUrl: string | null;
  chatUrl: string;
};
export type ActionCapabilitiesV1 = {
  version: "ixo.auth-capabilities/1";
  accountId: string;
  oracleDid: string;
  network: "ixo testnet" | "ixo devnet" | null;
  resourceOrigin: string | null;
  operations: ActionOperationV1["kind"][];
  forms: {
    formId: string;
    destination: string;
    fields: Omit<FormField, "value" | "source">[];
    declaration: string | null;
  }[];
  transfer: { maxAmountUixo: string; maxFeeUixo: string } | null;
};
export declare function canonicalJson(value: unknown): string;
export declare function digestOf(value: unknown): Promise<string>;
export declare function parseOperation(value: unknown): ActionOperationV1;
export declare function parseReference(value: unknown): ActionReferenceV1;
export declare function assertHubReferenceUrl(
  value: unknown,
  configuredOrigin: string,
): ActionReferenceV1;
export declare function parseReceipt(value: unknown): ActionReceiptV1;
export declare function parseOutcome(value: unknown): ActionOutcomeV1;
export declare function parseReviewView(value: unknown): ActionReviewView;
export declare function parseCapabilities(value: unknown): ActionCapabilitiesV1;
